package com.example.myapplication.strategy.duck.colleague.paul;

public interface DuckAction {
    String Quack(String str);
    String Fly(String str);
    String Show(String str);
}
