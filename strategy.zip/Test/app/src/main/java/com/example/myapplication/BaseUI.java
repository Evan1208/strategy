package com.example.myapplication;

public class BaseUI {


   public MainActivity mMainActivity;
}
