package com.example.myapplication.strategy.duck.fly;

public interface FlyBehavior {
    String fly();
}
