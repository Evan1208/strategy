package com.example.myapplication.strategy.weapon.status;

public interface LiveStatus {
    String status();
}
