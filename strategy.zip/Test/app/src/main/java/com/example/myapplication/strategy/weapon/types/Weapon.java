package com.example.myapplication.strategy.weapon.types;

public interface Weapon {

    String name();
    default void xxx(){

    }
}
