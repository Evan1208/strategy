package com.example.myapplication.strategy.duck.quack;

public interface QuackBehavior {
    String quack();
}
