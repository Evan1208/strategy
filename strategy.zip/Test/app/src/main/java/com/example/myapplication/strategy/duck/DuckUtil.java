package com.example.myapplication.strategy.duck;

public class DuckUtil {
    String mMallardDuck = "Mallard";
    String mStoneDuck = "Stone";
    String mModelDuck = "Model";
}
