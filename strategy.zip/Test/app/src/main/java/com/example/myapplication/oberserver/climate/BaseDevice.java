package com.example.myapplication.oberserver.climate;

abstract class BaseDevice {

    abstract void register();
    abstract void remove();
}
