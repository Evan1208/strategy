package com.example.myapplication.strategy.duck.fly;

public class FlyWithXddd implements FlyBehavior{

    @Override
    public String fly() {
        return "I'm flying!!";
    }
}
