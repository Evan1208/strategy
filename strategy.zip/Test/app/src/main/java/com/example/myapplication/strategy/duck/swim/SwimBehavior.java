package com.example.myapplication.strategy.duck.swim;

public interface SwimBehavior {
    String swim();
}
