package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

public class MyJava extends AppCompatActivity {

    public void myJava(String pst) {

        if( pst instanceof String) {

        }


        return;

    }
}
