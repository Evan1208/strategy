package com.example.myapplication.oberserver.climate.inter;

public interface DisplayElement {
    void display();
}
